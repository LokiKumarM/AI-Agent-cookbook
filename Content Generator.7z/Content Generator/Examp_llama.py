from litellm import completion

response = completion(model="ollama/llama3.2:1b",  # Specify Ollama provider and model
                       messages=[{"role": "user", "content": "What is the weather like today?"}])

print(response.choices[0].message.content)  # Access the generated response