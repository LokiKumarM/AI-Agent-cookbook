from crewai import Agent, Task, Crew, Process, LLM
##from langchain_community.llms import Ollama
##from langchain_ollama import OllamaLLM


model = LLM(
    model="ollama/llama3.2:1b",
)

job = "ADAS"

Get_Info = Agent(
    role = "Content Generator",
    goal = "To know about functionality of the various automotive systems and latest advancements made to improve the system",
    backstory = "You are an AI assistant whose only job is to provide the informative content about the automotive system."
                "don't hesitate to provide latest information feature of the automotive system.",
    verbose = True,
    allow_delegation = False,
    llm = model
)

Generate_Info = Agent(
    role = "Content Generator",
    goal = "Provide informative content about the given Automotive system. The information must include following points:"
           "Overview of functionality and architecture, Advantages, top competitor in designing the system",
    backstory = "You are an AI assistant whose only job is to provide the informative content about the automotive system."
                "don't hesitate to provide latest information feature of the automotive system.",
    verbose = True,
    allow_delegation = False,
    llm = model
)

task_get = Task(
    description = f"Tell me something about :'{job}'",
    agent = Get_Info,
    expected_output = "Gaining knowledge about given automotive system."
)

task_generate = Task(
    description = f"generate content about  '{job}' based on the knowledge gained by 'Get_Info' agent",
    agent = Generate_Info,
    expected_output = "Informative content about given automotive system"
)

crew = Crew(
    agent = [Get_Info, Generate_Info],
    tasks = [task_get, task_generate],
    verbose = True,
    process = Process.sequential
)

output = crew.kickoff()
print(output)